PHASTEST results processed from ZZ_739042d2ca.PHASTEST.zip

Genome: E. coli K-12 MG1655; sequence ID in supplied FASTA is "1"; length 4,641,652 bp.
Files:
- phastest_regions_annotated.tsv: 5 predicted regions from summary.txt, 1-based inclusive coordinates.
- phastest_regions.gff3: 5 regions with GFF3 seqid "1" to match input FASTA (not necessarily other annotations; adjust seqid if importing alongside NC_000913.3 tracks).
- original input archive retained by user; it includes detailed predicted genes and extracted phage-region FASTA.

PHASTEST class is an automated *score*, not proof of viable/infectious prophage. 'Top similarity hit' is not the established prophage locus identity.
Known region/locus mapping uses overlap of approximate PHASTEST regions with literature-curated loci from:
FEMS Microbiology Reviews, 2021: https://academic.oup.com/femsre/article/45/6/fuab032/6312496

Known loci may extend beyond PHASTEST boundaries and/or be smaller. Do not replace curated locus boundaries with PHASTEST predictions. Literature reports further prophage loci which PHASTEST did not call in this run.

Internal data issue: ends in predicted_phage_regions.json differ from the ends in summary.txt and phage_regions.fna by +46 nt for region 1, +13 nt for region 2, +11 nt for region 3. This export consistently uses summary.txt / phage_regions.fna end coordinates for all five regions. These are predicted intervals, not confirmed integration boundaries.
